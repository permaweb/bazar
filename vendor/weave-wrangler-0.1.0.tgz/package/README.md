# weave-wrangler

Fork-aware Arweave transaction tracking for browsers and Node. It observes the
same transaction through several independently addressed nodes, filters stale
observers, reports every lane, and only advances aggregate confirmation depth
when a quorum agrees on the same inclusion block.

It also includes a headless, resumable two-transaction purchase machine for
`~arweave-swap@1.0`.

## Why

One gateway is not one stable view of the weave. It may load-balance physical
nodes which alternately return `404`, `202 Pending`, and a confirmed status while
a transaction propagates. A single answer can therefore make a conventional UI
flicker or, worse, claim more certainty than the network supports.

weave-wrangler keeps two truths separate:

- An **observer view** is exactly what one IP/hostname most recently reported.
  It may move backwards and emits a `view` event whenever it does.
- **Consensus** is the threshold-agreed view of the active, in-sync observer set.
  Confirmations from different block hashes or heights are never combined.

“All nodes” means all reachable, in-sync observers currently known to this
client. Arweave's peer list is non-exhaustive, so no client can prove that every
node in the global network has seen a transaction.

## Install

```sh
npm install weave-wrangler
```

## Track a transaction

```ts
import { WeaveNetwork } from 'weave-wrangler';

const network = new WeaveNetwork({
	// The application owns its HTTP transport and may share it across libraries.
	fetch: window.aoFetch,
  // Tried first and shown first. It still loses its vote if it is out of sync.
  node: 'https://your-current-node.example',
  syncTolerance: 2,
  minObservers: 4,
});

network.on('info', (event) => {
  console.log(event.kind, event.observer?.label, event.message);
});

await network.ready();

const watcher = network.watch(transactionId, {
  target: 5,
  minObservers: 3,
  quorum: 'majority',
  propagation: 'all',
});

watcher.on('view', (view) => {
  renderObserverLane(view);
});

watcher.on('consensus', (consensus) => {
  renderHeadline(consensus);
});

// Fires only for forward threshold progress. Aggregate uncertainty and reorgs
// remain available through `consensus` and `orphaned`.
watcher.on('progress', persistProgress);
watcher.on('orphaned', showReorgWarning);
watcher.on('settled', showSettled);

watcher.start();
```

Call `watcher.stop()` and `network.stop()` when their owner is destroyed.

### Transaction status mapping

The core node contract is interpreted strictly:

| HTTP | Observation |
|---|---|
| `200` plus block hash, height, and confirmations | confirmed |
| `202` | pending |
| `404` | not found at this observer |
| `400` | malformed ID / caller error |
| `429` | rate limited |
| `503` with readable retry timing | rate limited |
| other `503` or transport failure | transient observer failure |

A malformed `200` is a protocol error, not “pending.” A confirmed quorum is
formed from observers which agree on both `block_indep_hash` and
`block_height`. If that quorum moves to another block, confirmation depth resets
and the watcher emits `orphaned` with `reorged: true`.

Numeric quorums are floors. If `quorum: 5` is configured and only two observers
answer, the watcher reports uncertainty; it never silently turns five into two.

## Browsers, peers, and relays

Core Arweave peers advertise clear-HTTP `IP:port` endpoints. An HTTPS page is
not allowed to open those endpoints because of browser mixed-content policy.
Rate-limit responses from core nodes may also be hidden by CORS before
JavaScript can read `Retry-After`.

The direct transport therefore records such peers as `mixed-content`. To render
their individual lanes from an HTTPS page, route requests through a HyperBEAM
node:

```ts
const network = new WeaveNetwork({
  node: 'https://current.example',
  'relay-with': 'https://hyperbeam.example',
	fetch: window.aoFetch,
});
```

Each logical `GET ORIGINAL_NODE_AND_PATH` becomes
`GET RELAY/~relay@1.0/call` with `relay-path: ORIGINAL_NODE_AND_PATH`.
Applications with another relay protocol may still supply an
`ObserverTransport` instead.

Every network must receive an explicit `fetch` transport. Applications can pass
one shared transport to observer and process-state libraries so they coordinate
physical-peer rate limits and `Retry-After` deadlines outside Weave Wrangler.

Peer-list private addresses are rejected by the library by default. Explicit
current nodes and static seeds are trusted caller input and may be private.

## Observer health and rate limits

`/info` is refreshed in the background. The working tip is derived from the
central height cohort, rather than the highest claim, so one broken or malicious
observer cannot make the honest network appear stale. Every observer is
reclassified whenever the cohort changes.

On a readable `429` (or a `503` with rate-limit timing), the observer is removed
from the active set until `Retry-After`/`RateLimit-Reset`. It is automatically
re-probed when that deadline expires. Set `evictRateLimited: false` only when the
application intentionally wants to keep querying it.

All calls to one observer are serialized, including calls made by different
transaction watchers.

GeoIP is disabled by default because it calls a third party and is neither
consensus data nor authoritative. Enable it with `geo: true` or provide a custom
`geoEndpoint`.

## Swap purchase lifecycle

`SwapPurchase` owns signing/dispatch order and L1 observation. The application
adapter owns transaction construction, wallet access, and process-state safety
checks.

```ts
import { SwapPurchase } from 'weave-wrangler';

const purchase = new SwapPurchase(network, {
  async prepareBoth(signal) {
    // Use wallet sign-only APIs, then return base-layer signed transactions.
    // Do not use wallet dispatch: it may produce a bundled data-item ID that
    // core `/tx/:id/status` cannot track.
    const registration = await signRegistration(signal);
    const payment = await signPayment(registration.id, signal);
    return { registration, payment };
  },

  async prepareRegistration(signal) {
    return signRegistration(signal);
  },

  async preparePayment(registrationId, signal) {
    return signPayment(registrationId, signal);
  },

  async waitForRegistrationAcceptance({ registrationId, signal, report }) {
    // For name tokens: rank compute providers and prove the order is reserved
    // for the connected buyer before any payment is sent.
    await verifyReservation(registrationId, signal, report);
  },

  async verifyOwnership({ paymentId, signal, report }) {
    await verifySettledOwnership(paymentId!, signal, report);
  },
}, {
  registrationTarget: 5,
  paymentTarget: 5,
  skipFrom: 2,
  paymentSuccessDepth: 1,
});

purchase.on('state', renderLocalizedPurchaseState);
purchase.on('success', enableOkButton);
purchase.on('complete', clearConfirmingBadge);
purchase.on('failed', showFailure);

void purchase.run();
```

Each `PreparedTransaction` exposes its already-signed `id` and an idempotent
`dispatch(signal)` which reposts that exact signed transaction. If POST times
out, the machine observes the known ID before retrying, avoiding duplicate
transactions.

The default flow is:

1. sign registration and, when supported, payment;
2. start observation before dispatching registration;
3. wait for all active observers to see it and for five confirmations;
4. expose `skipKind: "yolo"` at depth two and `"skip"` at depth three or four;
5. run the adapter's process-level reservation check;
6. dispatch the signed payment;
7. show successful, dismissible payment at depth one while tracking continues;
8. reach the configurable depth target;
9. run the adapter's ownership/settlement check; and
10. emit `complete`.

`dismiss()` only detaches the foreground renderer. It never stops tracking.
Persist `snapshot()` in an application provider; pass it back through `resume`
to continue dispatched IDs without posting them again. Each snapshot entry also
carries `dispatched`. If a crash occurred while POST was still ambiguous, the
adapter must implement `restorePrepared(which, id, signal)` and return the exact
signed transaction (kept by the application under that ID). The machine then
observes/reposts it idempotently; it never invents a replacement transaction.

Pre-signing is time-bounded. Arweave block anchors are accepted only within a
recent window and a quoted fee can become stale. Set `validUntilHeight` on a
prepared payment; if the registration wait reaches that height, the machine
asks `preparePayment` for a fresh signature before dispatch.

## Fork-risk helpers

`forkRisk(depth)`, `describeDepth(depth)`, and `skipLabel(depth)` expose the
product's current order-of-magnitude guidance:

- depth 2: about once a day;
- depth 3: about once a month;
- depth 4: about once every two years.

The table is intentionally centralized in `src/forks.ts` so measured data can
replace these initial estimates without changing application state machines.

## Validation

```sh
npm test
npm run typecheck
npm run build
npm run live:read
```

The funded live write test defaults to the dedicated secondary test wallet:

```sh
ARWEAVE_KEY=/secure/test-wallet.json npm run live:write -- 2
```

It creates a small base-layer data transaction and follows it from absent through
propagation and confirmation. Never point it at a production wallet.
