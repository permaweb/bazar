# ao.js

ao.js is a full caching, routing, and browser transport implementation for
AO-Core peers. It consumes HyperBEAM `~router@1.0` route tables, sends each
request to the matching peer or peers, persists hashpath responses, and gives
every library in one JavaScript realm one rate limiter for each physical origin.

## Install

```sh
npm install ao.js
```

## Use

Routes use the native `~router@1.0` shape. They are checked in order and the
first matching route wins:

```ts
import { ao } from 'ao.js';

const client = ao({
  routes: [
    {
      template: {
        path: '^/[^/]+~process@1.0/',
        method: 'GET',
      },
      nodes: [
        { prefix: 'https://alpha.example' },
        { prefix: 'https://charlie.example' },
      ],
      strategy: 'By-Base',
      choose: 1,
    },
  ],
});

// Start shared peer metadata/rate-limit discovery before the first visible read.
void client.warm();

const response = await client.fetch('/PROCESS~process@1.0/now');
```

An absolute request URL is already routed and remains explicit. A relative URL
is matched against `routes`; if no route matches, ao.js uses the optional
top-level `nodes` array as a catch-all pool:

```ts
const client = ao({
  nodes: [
    { prefix: 'https://alpha.example' },
    { prefix: 'https://charlie.example' },
  ],
});
```

With no routing configuration, relative requests retain normal same-origin
Fetch behavior. Once a route table or fallback pool is configured, an unmatched
request fails closed rather than leaking to the application origin.

## Import routes from HyperBEAM

The numbered JSON object returned by `~router@1.0` can be passed directly as
`routes`. ao.js preserves its numeric order and ignores response-envelope
fields such as `status`:

```ts
const routes = await fetch(
  'https://arweave.net/~meta@1.0/info/routes?accept=application/json&accept-bundle'
).then((response) => {
  if (!response.ok) throw new Error(`route discovery failed: ${response.status}`);
  return response.json();
});

const client = ao({ routes });
```

A route table is executable network policy: it decides which origins receive
request methods, headers, and bodies. Import tables only from nodes you trust.
When refreshing a remote table, replace its ordered rules explicitly instead
of appending them behind the old first-match rules:

```ts
client.replaceRoutes(await loadRoutes());
```

Inline node declarations require no separate registration. ao.js supports
the native node forms used by HyperBEAM:

- a URI string;
- `{ uri }` for an already constructed target;
- `{ prefix }` or `{ suffix }` to extend the request path; and
- `{ match, with }` to rewrite the request path.

Node `opts` and unknown fields survive route normalization, although
Erlang-specific HTTP client options have no browser equivalent.

## Named nodes

ao.js adds one optional extension to the native format: reusable named
nodes. Declare a map at the top level and refer to a node explicitly with
`{ ref }`:

```ts
const client = ao({
  nodes: {
    alpha: {
      prefix: 'https://alpha.example',
      'rate-limit': 'discover',
    },
    charlie: {
      prefix: 'https://charlie.example',
      'rate-limit': { requests: 20, period: 1 },
    },
  },
  routes: [
    {
      template: '^/[^/]+~process@1.0/',
      nodes: [{ ref: 'alpha' }, { ref: 'charlie' }],
      strategy: 'By-Base',
    },
  ],
});
```

The explicit object avoids confusing an alias with the URI strings accepted by
`~router@1.0`. Inline and named declarations can be mixed in one route.

## Route compatibility

A route template may be a path regular-expression string or a message template.
JavaScript regular-expression syntax is used in the browser; the common route
patterns used by HyperBEAM work directly, but this is not a promise that every
Erlang `re` extension has a JavaScript equivalent. Message templates can
constrain `path`, `route-path`, `method`, and other scalar request fields. As in
HyperBEAM, route order is semantic: ao.js does not combine routes merely
because their templates are equal.

`client.fetch(path, init)` supplies the normal path and method fields. Use
`client.request(message, init)` when selection also needs native routing metadata
such as `route-by`:

```ts
const response = await client.request(
  { path: '/arweave/chunk/123', method: 'GET', 'route-by': 123 },
);
```

The standard `fetch()` and `request()` methods return the first admissible
`Response`. When a native route requests a response quorum greater than one,
`requestMany(message, init)` exposes the complete admissible response set.

The browser router supports these native selection strategies:

- `All`, `Random`, `By-Base`, and `By-Weight`;
- `Range` and `Nearest-Integer`; and
- the corresponding `Shuffled-*` strategies.

It also reads `choose`, `parallel`, `responses`, `stop-after`,
`fallback-on-cooldown`, and `admissible-status` from native routes. Strategy
spelling is normalized in the same case-insensitive,
hyphen/underscore-tolerant manner as HyperBEAM.
Native `multirequest-*` fields on `client.request()` messages override the matching
route's multi-request policy as they do in HyperBEAM.

For serial `GET` and `HEAD` routes, `fallback-on-cooldown: true` defers a
candidate whose physical origin is already inside a known `Retry-After`
cooldown while another candidate remains. Ready candidates retain their
declared order. If every candidate is cooling down, ao.js waits for the one
with the earliest deadline. Non-idempotent requests never use this shortcut.

`Nearest` routes and executable AO-Core `admissible` messages cannot be
evaluated faithfully by the standalone browser library. They are retained in
the route table but reported as unsupported instead of being silently given
different semantics.

## Shared rate limiting

Calling `ao()` repeatedly in one JavaScript realm returns the same client and
merges additional configuration into it. `createAo()` makes
an intentionally isolated client, which is useful for tests and workers.
During the package rename, ao.js also aliases its compatible singleton under the
legacy `ao-wrangler.singleton` realm symbol so both names share one queue. A
capability-blind legacy singleton initialized first fails explicitly instead of
being relabelled as a client that supports policies it cannot enforce.

Rate-limit state belongs to the physical URL origin, not to a route or alias.
Consequently, two named nodes and several inline declarations that reach the
same origin share one queue, cooldown, and observed request rate.

By default, a peer discovers its advertised recharge rate and maximum balance from
the small JSON node message at `/~meta@1.0/info/serialize~json@1.0`. Integer
fields typed through `ao-types`, base64-carried nested bodies, and the
hyperbuddy `key => value` text form are all accepted. A node can instead declare a requests
per second number, `{ requests, period, burst }`, or `false` through `rate-limit`
(`rateLimit` is also accepted from JavaScript callers).

Discovery never holds a request. The first request to a discovering peer starts
the metadata read in the background; until it settles, that origin is paced at a
conservative provisional rate (`discoveryBurst` requests at once, then
`discoveryRequestsPerSecond`; 8 and 2 by default). An advertised limit then
becomes the peer ceiling. A peer that advertises no limit, or whose metadata is
unavailable, returns to the default adaptive pacing, which slows only after a
`429`.

When a peer returns `429`, ao.js:

- honors `Retry-After` for the entire origin;
- reduces the local dispatch rate at most once per control window;
- lets all queued requests observe the same cooldown; and
- recovers gradually toward the advertised or configured ceiling.

A serial route can opt into one hedged attempt for idempotent `GET` and `HEAD`
reads with `'hedge-after-ms'`. When the current candidate has not returned
headers by then, the next candidate starts too; the first admissible response
wins and the other attempt is aborted. A candidate that fails or answers with an
inadmissible status still fails over immediately. At most two attempts are in
flight, hedging is off when the field is absent, and it is ignored for other
methods, parallel routes, and multi-response quorums.

Only idempotent `GET` and `HEAD` requests are automatically replayed after a
route attempt returns `429`. This is separate from a route's own multi-node
policy: a native route may intentionally send any method, including `POST`, to
several declared peers serially or in parallel. Aborting a queued request
removes it from the peer queue without affecting other callers.

The singleton is scoped to one JavaScript realm. Separate tabs, workers, and
server processes do not share in-memory rate estimates.

## Persistent hashpath caching

Anonymous `GET` requests opt into ao.js's persistent browser cache with
normal HTTP cache directives. Entries are keyed by the logical routed hashpath
and request representation headers, so the same AO-Core result can survive a
peer failover and a page refresh:

```ts
import { ao, cacheMetadata } from 'ao.js';

const response = await ao().fetch('/PROCESS~process@1.0/now', {
  headers: {
    'cache-control': 'max-age=30, stale-while-revalidate=86400',
    accept: 'application/json',
  },
});
const cache = cacheMetadata(response);
const state = await response.json();

if (cache?.status === 'stale') {
  const freshState = await cache.revalidation?.then((fresh) => fresh.json());
}
```

Fresh entries return without network traffic. An entry inside its
`stale-while-revalidate` window returns immediately while exactly one shared
background request refreshes it through the normal router and rate limiter.
At most four distinct background refreshes enter transport at once, so a warm
page cannot queue its entire stale working set ahead of a foreground request.
A read sent with `priority: 'high'` marks what the caller is showing: its
refresh starts immediately with foreground admission, outside that bound, and a
queued background refresh of the same entry is promoted rather than left
waiting behind unrelated stale entries.
`cacheMetadata(response)` reports `fresh`, `stale`, or `miss`, the entry age in
seconds, and the revalidation promise when one exists. This lets callers render
stale state provisionally and replace it explicitly when current state arrives.

The browser implementation uses Cache Storage and retains at most 256 recent
hashpaths. Runtimes without Cache Storage use the same behavior in memory.
Requests with credentials, authorization, cookies, ranges, non-`GET` methods, or `no-store`
are never persisted. `cache: 'reload'` and `cache: 'no-cache'` bypass reads;
`cache: 'no-store'` bypasses both reads and writes. Peer response `no-store`
also wins. Without an explicit request `max-age`, ao.js does not cache.

## Browser limitations

Route compatibility does not override browser security. A route imported from a
node may still be unusable from a page when its destination:

- does not permit the page through CORS;
- is plain HTTP while the page is HTTPS;
- names a loopback service such as `localhost:6363`; or
- requires Erlang-specific transport options from the node's `opts` map.

These failures concern reachability from the browser, not route parsing. An
application can supply browser-appropriate ordered routes or use named nodes
while retaining the same `~router@1.0` data model.

## Policy and inspection

`controlWindowMs`, `decreaseFactor`, `recoveryFactor`, `maxRetries`, and the
other policy fields tune adaptive throttling. Independent declarations merge
conservatively so that one library cannot silently raise another library's
peer limit.

`client.snapshot()` reports effective routes and current per-origin rates. Queued
requests remain abortable throughout route selection and rate-limit waits.
Each peer attempt also has a configurable `requestTimeoutMs` deadline (30 seconds
by default). The deadline starts when the HTTP request is sent; time spent
waiting for a rate-limit token is bounded separately by the same duration, so a
queued request is never charged for the queue. After either deadline, a serial
route may fail over to its next candidate.

## Validate

```sh
npm test
npm run typecheck
npm run build
```
