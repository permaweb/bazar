# AO Wrangler

AO Wrangler is a shared browser transport for AO-Core peers. It consumes
HyperBEAM `~router@1.0` route tables, sends each request to the matching peer or
peers, and gives every library in one JavaScript realm one rate limiter for each
physical origin.

## Install

```sh
npm install ao-wrangler
```

## Use

Routes use the native `~router@1.0` shape. They are checked in order and the
first matching route wins:

```ts
import { aoWrangler } from 'ao-wrangler';

const ao = aoWrangler({
  routes: [
    {
      template: {
        path: '^/[^/]+~process@1.0/',
        method: 'GET',
      },
      nodes: [
        { prefix: 'https://alpha.example' },
        { prefix: 'https://charlie.example' },
      ],
      strategy: 'By-Base',
      choose: 1,
    },
  ],
});

const response = await ao.fetch('/PROCESS~process@1.0/now');
```

An absolute request URL is already routed and remains explicit. A relative URL
is matched against `routes`; if no route matches, AO Wrangler uses the optional
top-level `nodes` array as a catch-all pool:

```ts
const ao = aoWrangler({
  nodes: [
    { prefix: 'https://alpha.example' },
    { prefix: 'https://charlie.example' },
  ],
});
```

With no routing configuration, relative requests retain normal same-origin
Fetch behavior. Once a route table or fallback pool is configured, an unmatched
request fails closed rather than leaking to the application origin.

## Import routes from HyperBEAM

The numbered JSON object returned by `~router@1.0` can be passed directly as
`routes`. AO Wrangler preserves its numeric order and ignores response-envelope
fields such as `status`:

```ts
const routes = await fetch(
  'https://arweave.net/~meta@1.0/info/routes?accept=application/json&accept-bundle'
).then((response) => {
  if (!response.ok) throw new Error(`route discovery failed: ${response.status}`);
  return response.json();
});

const ao = aoWrangler({ routes });
```

A route table is executable network policy: it decides which origins receive
request methods, headers, and bodies. Import tables only from nodes you trust.
When refreshing a remote table, replace its ordered rules explicitly instead
of appending them behind the old first-match rules:

```ts
ao.replaceRoutes(await loadRoutes());
```

Inline node declarations require no separate registration. AO Wrangler supports
the native node forms used by HyperBEAM:

- a URI string;
- `{ uri }` for an already constructed target;
- `{ prefix }` or `{ suffix }` to extend the request path; and
- `{ match, with }` to rewrite the request path.

Node `opts` and unknown fields survive route normalization, although
Erlang-specific HTTP client options have no browser equivalent.

## Named nodes

AO Wrangler adds one optional extension to the native format: reusable named
nodes. Declare a map at the top level and refer to a node explicitly with
`{ ref }`:

```ts
const ao = aoWrangler({
  nodes: {
    alpha: {
      prefix: 'https://alpha.example',
      'rate-limit': 'discover',
    },
    charlie: {
      prefix: 'https://charlie.example',
      'rate-limit': { requests: 20, period: 1 },
    },
  },
  routes: [
    {
      template: '^/[^/]+~process@1.0/',
      nodes: [{ ref: 'alpha' }, { ref: 'charlie' }],
      strategy: 'By-Base',
    },
  ],
});
```

The explicit object avoids confusing an alias with the URI strings accepted by
`~router@1.0`. Inline and named declarations can be mixed in one route.

## Route compatibility

A route template may be a path regular-expression string or a message template.
JavaScript regular-expression syntax is used in the browser; the common route
patterns used by HyperBEAM work directly, but this is not a promise that every
Erlang `re` extension has a JavaScript equivalent. Message templates can
constrain `path`, `route-path`, `method`, and other scalar request fields. As in
HyperBEAM, route order is semantic: AO Wrangler does not combine routes merely
because their templates are equal.

`ao.fetch(path, init)` supplies the normal path and method fields. Use
`ao.request(message, init)` when selection also needs native routing metadata
such as `route-by`:

```ts
const response = await ao.request(
  { path: '/arweave/chunk/123', method: 'GET', 'route-by': 123 },
);
```

The standard `fetch()` and `request()` methods return the first admissible
`Response`. When a native route requests a response quorum greater than one,
`requestMany(message, init)` exposes the complete admissible response set.

The browser router supports these native selection strategies:

- `All`, `Random`, `By-Base`, and `By-Weight`;
- `Range` and `Nearest-Integer`; and
- the corresponding `Shuffled-*` strategies.

It also reads `choose`, `parallel`, `responses`, `stop-after`, and
`admissible-status` from native routes. Strategy spelling is normalized in the
same case-insensitive, hyphen/underscore-tolerant manner as HyperBEAM.
Native `multirequest-*` fields on `ao.request()` messages override the matching
route's multi-request policy as they do in HyperBEAM.

`Nearest` routes and executable AO-Core `admissible` messages cannot be
evaluated faithfully by the standalone browser library. They are retained in
the route table but reported as unsupported instead of being silently given
different semantics.

## Shared rate limiting

Calling `aoWrangler()` repeatedly in one JavaScript realm returns the same
client and merges additional configuration into it. `createAoWrangler()` makes
an intentionally isolated client, which is useful for tests and workers.

Rate-limit state belongs to the physical URL origin, not to a route or alias.
Consequently, two named nodes and several inline declarations that reach the
same origin share one queue, cooldown, and observed request rate.

By default, a peer discovers its advertised rate from
`/~meta@1.0/info/format~hyperbuddy@1.0`. A node can instead declare a requests
per second number, `{ requests, period }`, or `false` through `rate-limit`
(`rateLimit` is also accepted from JavaScript callers).

When a peer returns `429`, AO Wrangler:

- honors `Retry-After` for the entire origin;
- reduces the local dispatch rate at most once per control window;
- lets all queued requests observe the same cooldown; and
- recovers gradually toward the advertised or configured ceiling.

Only idempotent `GET` and `HEAD` requests are automatically replayed after a
route attempt returns `429`. This is separate from a route's own multi-node
policy: a native route may intentionally send any method, including `POST`, to
several declared peers serially or in parallel. Aborting a queued request
removes it from the peer queue without affecting other callers.

The singleton is scoped to one JavaScript realm. Separate tabs, workers, and
server processes do not share in-memory rate estimates.

## Browser limitations

Route compatibility does not override browser security. A route imported from a
node may still be unusable from a page when its destination:

- does not permit the page through CORS;
- is plain HTTP while the page is HTTPS;
- names a loopback service such as `localhost:6363`; or
- requires Erlang-specific transport options from the node's `opts` map.

These failures concern reachability from the browser, not route parsing. An
application can supply browser-appropriate ordered routes or use named nodes
while retaining the same `~router@1.0` data model.

## Policy and inspection

`controlWindowMs`, `decreaseFactor`, `recoveryFactor`, `maxRetries`, and the
other policy fields tune adaptive throttling. Independent declarations merge
conservatively so that one library cannot silently raise another library's
peer limit.

`ao.snapshot()` reports effective routes and current per-origin rates. Queued
requests remain abortable throughout route selection and rate-limit waits.

## Validate

```sh
npm test
npm run typecheck
npm run build
```
