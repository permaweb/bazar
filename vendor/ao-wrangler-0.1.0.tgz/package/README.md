# AO Wrangler

AO Wrangler is the shared browser transport for AO-Core peers. It routes relative
AO paths to configured nodes and ensures that every library in one JavaScript
realm shares the same rate-limit state for each physical peer.

```ts
import { aoWrangler } from 'ao-wrangler';

const ao = aoWrangler({
  nodes: ['https://alpha.example'],
  routes: {
    '^/[^/]+~process@1.0/': ['https://alpha.example', 'https://charlie.example'],
  },
});

const response = await ao.fetch('/PROCESS~process@1.0/now');
```

Calling `aoWrangler()` again returns the same realm-wide client. New nodes are
unioned into existing pools and routes with the same match are merged. Routes
are checked by priority and then declaration order; relative requests use the
first matching route, while absolute URLs remain explicit.

Registered nodes discover their sustainable request rate from
`/~meta@1.0/info/format~hyperbuddy@1.0`. A `429` blocks the entire physical
origin, honors `Retry-After`, and reduces its local rate once per control
window. Only `GET` and `HEAD` requests are retried automatically.

The configuration is plain data, so an application can restore a wallet's
preferred nodes before making requests:

```ts
aoWrangler({
  nodes: [{ url: walletPreference, rateLimit: 'discover' }],
  routes: [
    {
      id: 'process-state',
      match: /~process@1\.0\/(?:now|compute)/,
      nodes: [walletPreference],
      strategy: 'first',
    },
  ],
});
```

Calling code does not need to know which library first created the client.
Each declaration is merged into the existing node and route pools. Use
`createAoWrangler()` only for an intentionally isolated client, such as a test
or a self-contained worker.

The singleton is intentionally scoped to a JavaScript realm. Separate browser
tabs do not share memory or rate estimates.
